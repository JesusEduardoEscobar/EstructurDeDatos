// Equipo 5
// Ãngel Gabriel Camacho PÃ©rez - A01743075
// Ana Paula Navarro HernÃ¡ndez - A01644875
// JesÃºs Eduardo Escobar Meza - A01743270
// DescripciÃ³n: Este programa maneja una lista enlazada de registros y lee un archivo que contienen registros los cuales se ordenan de menor a mayor usando la IP de los regstros y genera un nuevo archivo con los regisrtros ordenados
// ademas de que permite hacer la busqueda de los registros que se quieren ingresar pidiendo al usuario un rango que tiene un inicio y un fin dichos registros son almacenados en un nuevo archivo .txt
// Fecha: 12 de octubre del 2024

#ifndef REGISTRO_H
#define REGISTRO_H

#include <iostream>
#include <vector>
#include <iomanip> 
using namespace std;

class Registro{
private:
    //Atributos que almacenan la información de un registro
    string mes;
    string dia;
    string tiempo;
    string direccionIP;
    string razon;
    long long int IP_ID;

    long long int ConstruirID(); //Método para generar un ID 
    
public:
    Registro *next;

    Registro();
    Registro(string linea, Registro* next);
    Registro(string mes, string dia, string tiempo, string direccionIP, string razon, Registro* next);

    //Métodos de acceso (getters)
    void InsertLine(string linea);
    string GetMes();
    string GetDia();
    string GetTiempo();
    string GetDireccionIP();
    string GetRazon();
    string GetRegistroStr();
    long long int GetID(); 
};

#endif