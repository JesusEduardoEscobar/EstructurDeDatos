// Equipo 5
// Ãngel Gabriel Camacho PÃ©rez - A01743075
// Ana Paula Navarro HernÃ¡ndez - A01644875
// JesÃºs Eduardo Escobar Meza - A01743270
// DescripciÃ³n: Este programa maneja una lista enlazada de registros y lee un archivo que contienen registros los cuales se ordenan de menor a mayor usando la IP de los regstros y genera un nuevo archivo con los regisrtros ordenados
// ademas de que permite hacer la busqueda de los registros que se quieren ingresar pidiendo al usuario un rango que tiene un inicio y un fin dichos registros son almacenados en un nuevo archivo .txt
// Fecha: 12 de octubre del 2024

#include "Bitacora.h"
#include <iostream>
#include <fstream> //para manipular los archivos 
#include <vector> 
#include <stdexcept> //para manejar excepciones

using namespace std;

int main(){
    string resp; 
    bool repeticion= true;
    int N=1; //Contador para exportar registros
    int i;

    //Sirve para carga la bitácora a partir de un archivo.
    Bitacora* archivo= new Bitacora();
    archivo->LeerArchivo("bitacora-1.txt");
    archivo->OrdenarBitacora();

    while(repeticion){ //ciclo para repetir el programa 
        //Activa la búsqueda de registros por fecha y manda un aviso si ocurre un error al ingresar los datos mal
        try {
            archivo->BuscarRegistro(N);
            N++;
        } 
        catch (const std::length_error& e) {
            cout<< "Error ocurrido al ingresar los datos, favor de hacerlo de nuevo." <<"\n";
        } 
        while(true){
            //Pregunta al usuario si desea buscar otro rango de fechas
            cout<<"Quieres hacer otra busqueda (y/n)?"<<endl;
            getline(cin, resp);
            if(resp == "y"){
                cout<<"\n";
                break; //Regresa al inicio del bucle principal
            }
            else if(resp == "n"){
                cout<<"Gracias por usar el programa"<<endl;
                repeticion=false; //Termina el bucle principal
                break;
            }
            else{
                cout<<"Respuesta invalida"<<endl<<endl;
            }   
        }
    }

    // Borrar las bitacoras dinámicas
    delete archivo;
    
    return 0; 
}