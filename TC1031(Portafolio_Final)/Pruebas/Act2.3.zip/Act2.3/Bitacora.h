// Equipo 5
// Ãngel Gabriel Camacho PÃ©rez - A01743075
// Ana Paula Navarro HernÃ¡ndez - A01644875
// JesÃºs Eduardo Escobar Meza - A01743270
// DescripciÃ³n: Este programa maneja una lista enlazada de registros y lee un archivo que contienen registros los cuales se ordenan de menor a mayor usando la IP de los regstros y genera un nuevo archivo con los regisrtros ordenados
// ademas de que permite hacer la busqueda de los registros que se quieren ingresar pidiendo al usuario un rango que tiene un inicio y un fin dichos registros son almacenados en un nuevo archivo .txt
// Fecha: 12 de octubre del 2024

#ifndef BITACORA_H
#define BITACORA_H

#include "Registro.h"

#include <iostream>
#include <vector>
#include <iomanip>  
using namespace std;

class  Bitacora{
private:
    int size;
        Registro *head,
                 *tail;

    Registro* busqSecuencial(long long int ini_ID);
    Registro* OrdenaMerge(Registro* iniNodo, Registro* finNodo);
    Registro* Mezcla(Registro* iniNodo, Registro* cenNodo); 
    
public:
    Bitacora(Registro* registro); //Constructor por defaut
    Bitacora(); //Constructor
    ~Bitacora(); //Destructor

    void LeerArchivo(string archivo); //Obtiene los registros contenidos en un archivo

    int GetSize(); //Retorna la cantidad de registros en la bitácora
    void OrdenarBitacora(); //Ordena los registros de la bitácora

    bool IsEmpty();
    void RemoveLast(); //Exc invalid_argument
    void InsertFirst(string data); //Exc invalid_argument
    void BuscarRegistro(int N); //Funcion para buscar registros en cierto rango. Manda el número de busqueda
};

#endif